var inicio = 0;
var tiem = 0;
var modo = "p";
var vFal = 0;
var vReh = 0;
var vEli = 0;

var intervalo;
var retNoPing = 60000;
var noPingTimer = setTimeout(noPing, retNoPing);
var connection = new WebSocket('ws://' + location.host + '/');
var liberaResetTimer;

var tiempo = document.getElementById("tiempo");

var bFal = document.getElementById("bfal");
var bLaf = document.getElementById("blaf");
var bReh = document.getElementById("breh");
var bHer = document.getElementById("bher");
var bRec = document.getElementById("brec");
var bIni = document.getElementById("bini");
var bEli = document.getElementById("beli");
var bRes = document.getElementById("bres");
var tFal = document.getElementById("tFal");
var tReh = document.getElementById("tReh");

var tiempos = document.getElementById("tiempos");
var errorCel = document.getElementById("errorCel");

var turno = document.getElementById("turno");
var talla = document.getElementById("talla");

connection.onopen = function () { connection.send("d0"); connection.send("050"); };
connection.onmessage = function (mensaje) {
    const dato = mensaje.data;
    if (dato === '__ping__') {
        clearTimeout(noPingTimer);
        noPingTimer = setTimeout(noPing, retNoPing);
        return;
    } else if (isNaN(dato.substring(0, 1)) && dato.length === 11) {
        if (tiempo) {
            console.log(dato);
            modo = dato.substring(0, 1);
            vFal = dato.substring(1, 2) * 1;
            vReh = dato.substring(2, 3) * 1;
            vEli = dato.substring(3, 4) * 1;
            tiem = dato.substring(4) * 1;
            resetBotones();
            clearInterval(intervalo);

            /* AJUSTAR CRONO */
            if (modo === "i") {
                inicio = new Date().getTime() - tiem;
                reloj(tiem, 0);
                intervalo = setInterval(function () { crono() }, 100);
            }
            if (modo === "p") {
                inicio = new Date().getTime() - tiem;
                reloj(tiem, 1);
                clearTimeout(liberaResetTimer);
                if (dato != 'p0000000000') {
                    liberaResetTimer = setTimeout(() => {
                        document.getElementById("bres").disabled = false;
                    }, 5000);
                }
            }
            if (modo === "g" || modo === "o" || modo === "s" || modo === "q") {
                inicio = new Date().getTime() + tiem;
                reloj(tiem, 0);
            }
            if (modo === "g" || modo === "s") {
                intervalo = setInterval(function () { atras() }, 100);
            }

            /* AJUSTAR BOTONES DESHABILITADOS*/
            if (modo === "i" || modo === "p") miraNormal(dato);
            if (modo === 'g' || modo === 'o') miraCuenta();
            if (modo === "s" || modo === "q") miraSalida();
            if (modo === "i" || modo === "p" || modo === "s" || modo === "q") miraElimi();
        }
    } else {
        var datos = dato.split(";");
        if (datos[0] === "020") {
            if (tiempos) {
                console.log(dato);
                let tiempo = 0;
                let listado = "<table><tr><th>Hora</th><th>Tiempo</th><th>Faltas</th><th>Rehuses</th><th></th></tr>";
                for (var i = 1; i < datos.length; i++) {
                    let campos = datos[i].split('\t');
                    if (campos.length > 4) {
                        listado += "<tr><td>" + campos[0] + "</td>";
                        listado += "<td>" + campos[1].substring(0, campos[1].length - 1) + "</td>";
                        listado += "<td>" + campos[2] + "</td>";
                        listado += "<td>" + campos[3] + "</td>";
                        if (campos[4] === '1') {
                            listado += "<td>Eliminado</td></tr>";
                        } else {
                            listado += "<td></td></tr>";
                        }
                    }
                }
                listado += "</table>";
                document.getElementById("tiempos").innerHTML = listado;
            }
        } else if (datos[0] === "022") {
            if (errorCel) {
                console.log(dato);
                if (datos[5] > 0) {
                    errorCel.style.color = "red";
                    errorCel.innerHTML = "CELULA DESALINEADA";
                } else if (datos[1] === 0 || datos[2] === 0 || datos[3] === 0 || datos[4] === 0) {
                    errorCel.style.color = "red";
                    errorCel.innerHTML = "BATERIA AGOTADA";
                } else if (datos[1] <= 15 || datos[2] <= 15 || datos[3] <= 15 || datos[4] <= 15) {
                    errorCel.style.color = "red";
                    errorCel.innerHTML = "BATERIA MUY BAJA";
                } else if (datos[1] <= 30 || datos[2] <= 30 || datos[3] <= 30 || datos[4] <= 30) {
                    errorCel.style.color = "orange";
                    errorCel.innerHTML = "BATERIA BAJA";
                } else {
                    errorCel.style.color = "green";
                    errorCel.innerHTML = "CELULAS OK";
                }
            }
        } else if (datos[0] === "050") {
            if (turno) {
                console.log(dato);
                document.getElementById("turno").innerHTML = datos[1];
                if ((datos[2] * 1) > 0) {
                    document.getElementById("talla").value = datos[2];
                } else {
                    document.getElementById("talla").value = 0;
                }
            }
        }
    }
};
function crono() {
    reloj(new Date().getTime() - inicio, 0);
}
function atras() {
    let actual = inicio - (new Date().getTime());
    if (actual < 0) {
        clearInterval(intervalo);
        reloj(0, 0);
        if (modo === 'g') {
            modo = 'p';
            vFal = 0;
            vReh = 0;
            vEli = 0;
            resetBotones();
            miraNormal('p0000000000');
        } else if (modo === 's') {
            modo = 'i';
            intervalo = setInterval(function () { crono() }, 100);
        }
    } else {
        reloj(actual, 0);
    }
}
function reloj(elapsed, muestraCentesimas) {
    let valor = "00.00";
    let enteros = Math.floor(elapsed / 1000);
    let decimal = ("000" + elapsed % 1000).slice(-3);
    let minutos = Math.floor(enteros / 60);
    let segundos = enteros % 60;

    if (minutos < 10) minutos = "0" + minutos;
    if (segundos < 10) segundos = "0" + segundos;

    if ((modo === 'o' || modo === 'g') && elapsed > 0) {
        valor = minutos + ":" + segundos;

    } else if (elapsed > 0) {
        if (muestraCentesimas) {
            decimal = decimal.substring(0, 2);
        } else {
            decimal = decimal.substring(0, 1) + "0";
        }
        valor = enteros + "." + decimal;
        if (elapsed < 10000) valor = "0" + valor;
    }
    tiempo.innerHTML = valor;
}
function resetBotones() {
    bFal.disabled = false;
    bLaf.disabled = false;
    bReh.disabled = false;
    bHer.disabled = false;
    bRec.disabled = false;
    bIni.disabled = false;
    bEli.disabled = false;
    bRes.disabled = false;
    tFal.innerHTML = "F:" + vFal;
    tReh.innerHTML = "R:" + vReh;
    bRec.innerHTML = "Recon.";
    bIni.innerHTML = "Iniciar";
    bEli.innerHTML = "Elim.";
}
function miraNormal(dato) {
    // modificar botones para modo normal
    bIni.disabled = true;
    if (dato === 'p0000000000') {
        bFal.disabled = true;
        bLaf.disabled = true;
        bHer.disabled = true;
    } else {
        brec.disabled = true;
    }
}
function miraCuenta() {
    // modificar botones para modo reconocimiento de pista
    bFal.disabled = true;
    bLaf.disabled = true;
    bReh.disabled = true;
    bHer.disabled = true;
    bRec.innerHTML = "+1 min.";
    bEli.innerHTML = "-1 min.";
    if (modo === 'g') bIni.innerHTML = "Pausa";
}
function miraSalida() {
    // modificar botones para modo salida
    bFal.disabled = true;
    bLaf.disabled = true;
    bHer.disabled = true;
    if (modo === 's') {
        bRec.disabled = true;
        bIni.disabled = true;
    }
}
function miraElimi() {
    // modificar botones 
    if (vEli === 1) {

        bEli.innerHTML = "No Elim";

        tReh.innerHTML = "Elim.";
        bReh.disabled = true;
        bHer.disabled = true;

        tFal.innerHTML = "Elim.";
        bFal.disabled = true;
        bLaf.disabled = true;

    } else {
        bRes.disabled = true;
    }
}

function falta() { connection.send("f1"); }
function atlaf() { connection.send("f0"); }
function rehus() { connection.send("r1"); }
function suher() { connection.send("r0"); }
function borra() { connection.send("b0"); }
function elimi() { connection.send("e0"); }
function recon() { connection.send("c0"); }
function inici() { connection.send("g0"); }

function masUno() { connection.send("150;1;" + talla.value); }
function masDiez() { connection.send("150;10;" + talla.value); }
function menosUno() { connection.send("150;-1;" + talla.value); }
function menosDiez() { connection.send("150;-10;" + talla.value); }

function noPing() { location.reload(); }
