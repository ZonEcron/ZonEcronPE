/* modificar colores en funcion al puerto */
let puerto = location.host.split(':')[1];
let r = document.querySelector(':root');
let logoSVG = document.getElementById("svg-1");
if (puerto === '8081') {            // azul
    r.style.setProperty('--cBorde', '#00C');
    r.style.setProperty('--cOscur', '#04F');
    r.style.setProperty('--cClaro', '#8CF');
    r.style.setProperty('--cFLogo', '#DEF');
} else if (puerto === '8082') {     // blanco
    r.style.setProperty('--cBorde', '#444');
    r.style.setProperty('--cOscur', '#888');
    r.style.setProperty('--cClaro', '#CCC');
    r.style.setProperty('--cFLogo', '#FFF');
} else if (puerto === '8083') {     //rojo
    r.style.setProperty('--cBorde', '#800');
    r.style.setProperty('--cOscur', '#C00');
    r.style.setProperty('--cClaro', '#F88');
    r.style.setProperty('--cFLogo', '#FCC');
} else if (puerto === '8084') {     //naranja
    r.style.setProperty('--cBorde', '#C40');
    r.style.setProperty('--cOscur', '#F80');
    r.style.setProperty('--cClaro', '#FC8');
    r.style.setProperty('--cFLogo', '#FED');
} else if (puerto === '8085') {     //morado
    r.style.setProperty('--cBorde', '#628');
    r.style.setProperty('--cOscur', '#84A');
    r.style.setProperty('--cClaro', '#A6C');
    r.style.setProperty('--cFLogo', '#EDF');
} else if (puerto === '8086') {     //gris oscuro
    r.style.setProperty('--cBorde', '#000');
    r.style.setProperty('--cOscur', '#333');
    r.style.setProperty('--cClaro', '#555');
    r.style.setProperty('--cFLogo', '#777');
} else if (puerto === '8087') {     //aguamar
    r.style.setProperty('--cBorde', '#044');
    r.style.setProperty('--cOscur', '#488');
    r.style.setProperty('--cClaro', '#8CC');
    r.style.setProperty('--cFLogo', '#CFF');
} else if (puerto === '8088') {     //verde
    r.style.setProperty('--cBorde', '#040');
    r.style.setProperty('--cOscur', '#080');
    r.style.setProperty('--cClaro', '#8C8');
    r.style.setProperty('--cFLogo', '#CFC');
} else if (puerto === '8089') {     //amarillo
    r.style.setProperty('--cBorde', '#880');
    r.style.setProperty('--cOscur', '#CC0');
    r.style.setProperty('--cClaro', '#FF8');
    r.style.setProperty('--cFLogo', '#FFC');
}  

/* modificar relleno del logotipo */
if (logoSVG) logoSVG.style.fill = getComputedStyle(document.body).getPropertyValue('--cBorde');
