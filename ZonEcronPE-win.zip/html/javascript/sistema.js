const redes = document.getElementById("redes");
redes.innerHTML = `
    <label class="subr"><a href="http://${location.host}/">http://${location.host}/</a></label><br>
    <label class="subr">???</label><br>
    `
var connection = new WebSocket('ws://' + location.host + '/');
connection.onopen = function () { connection.send("020"); };
connection.onmessage = function (mensaje) {
    const datos = mensaje.data.split(";");
    if (datos[0] == "020") {
        tabla = "<tr><th>nº</th><th>Hora</th><th>Tiempo</th><th>Fal</th><th>Reh</th><th>Eli</th></tr>";
        lineas = datos.slice(1);
        for (let i = 0; i < lineas.length; i++) {
            const campos = lineas[i].split('\t');
            const num = i + 1;
            tabla += "<tr>";
            tabla += "<td>" + num + "</td>";
            tabla += "<td>" + campos[0] + "</td>";
            tabla += "<td>" + campos[1] + "</td>";
            tabla += "<td>" + campos[2] + "</td>";
            tabla += "<td>" + campos[3] + "</td>";
            tabla += "<td>" + ((campos[4] === '1') ? 'Eliminado' : '') + "</td>";
            tabla += "</tr>";
        }
        document.getElementById("tiempos").innerHTML = tabla;
        connection.close();
    }
    if (datos[0] == "022") {
        console.log(mensaje.data);
        if (datos[1] != "999") document.getElementById("c1r").innerHTML = datos[1] + " %";
        if (datos[2] != "999") document.getElementById("c1e").innerHTML = datos[2] + " %";
        if (datos[3] != "999") document.getElementById("c2r").innerHTML = datos[3] + " %";
        if (datos[4] != "999") document.getElementById("c2e").innerHTML = datos[4] + " %";
    }
    if (datos[0] == "023") {
        console.log(mensaje.data);
        if (datos[1]) document.getElementById("Fab").innerHTML = datos[1];
        if (datos[2]) document.getElementById("Cod").innerHTML = datos[2];
    }
    if (datos[0] == "024") {
        console.log(mensaje.data);
        let listaRedes = '<label class="subr">' + 'http://' + location.host + '/' + '</label><br>\n'
        for ( let i = 1 ; i < datos.length ; i++) {
            listaRedes += datos[i];
        }
        redes.innerHTML = listaRedes;
    }
}
