## ZONECRON PUERTA DE ENLACE - LICENCIA V 0.3.1

La puerta de enlace ZonEcron (este software) comunica cronómetros con mochila ZonEcron con un software de gestión de competiciónes que sea compatible, mediante conexión websocket.

## LICENCIA DE USO MIT

### Es copyright (C) 2024 de Jon Bilbao - danebae@gmail.com

Por la presente se concede permiso, libre de cargos, a cualquier persona que obtenga una copia de este software y de los archivos de documentación asociados (el "Software"), a utilizar el Software sin restricción, incluyendo sin limitación, los derechos a usar, copiar, modificar, fusionar, publicar, distribuir, sublicenciar, y/o vender copias del Software, y a permitir a las personas a las que se les proporcione el Software a hacer lo mismo, sujeto a las siguientes condiciones:

1 - El aviso de copyright anterior y este aviso de permiso se incluirán en todas las copias o partes sustanciales del Software.

2 - El software se proporciona "como está", sin garantía de ningún tipo, expresa o implícita, incluyendo pero no limitado a garantías de comercialización, idoneidad para un propósito particular e incumplimiento. en ningún caso los autores o propietarios de los derechos de autor serán responsables de ninguna reclamación, daños u otras responsabilidades, ya sea en una acción de contrato, agravio o cualquier otro motivo, derivadas de, fuera de o en conexión con el software o su uso u otro tipo de acciones en el software.

