# ZONECRON PUERTA DE ENLACE - MANUAL V 0.3.1

## ANTES DE EMPEZAR
1. Asegúrate que el ordenador reconoce la mochila ZonEcron cuando la conectas. Normalmente debería sonar un tono al conectar cualquier equipo USB. Si no es así tendrás que instalar los drivers para el chip CH340G. Una búsqueda en google vale más que mil palabras.
2. Desconecta la mochila ZonEcron del ordenador.
3. Si vas a conectar con Flow Agility, asegúrate que el ordenador tiene acceso a internet navegando a alguna pagina web.

## CONECTAR CON MOCHILA ZONECRON
1. Al ejecutar este programa se abre una ventana que no debes cerrar y también una pagina web con dirección http://localhost:8080 o similar terminando en diferentes números entre el 8080 y 8100.
2. La pagina web muestra la licencia de uso que deberías leer. Dispone de un menu de 4 opciones (Información, Conectar, Mandos y Pantallas) Pinchando en la sección conectar aparecen el sub-menú con "Mochila" y "Flow Agility". Pincharemos en "Mochila". A partir de aquí nos referiremos a este camino como **Conectar -> Mochila** o parecido para otros caminos en la web.
3. Se abre una nueva web en el que aparece un desplegable con los puertos serie que tiene el ordenador. Fíjate bien en cuales son.
4. Conecta la mochila ZonEcron al ordenador.
5. Dale a refrescar y mira de nuevo los puertos serie que aparecen y elige el que antes no estaba y que haya aparecido nuevo.
6. Dale a conectar y espera a que aparezca el mensaje: "Conectado. Sin verificar" en ámbar.
7. Corta el crono para que arranque o pare y el mensaje debería cambiar a "Conectado. Mochila OK" en verde. Si no es así repasa todo el proceso desde el punto 4.

## CONECTAR CON FLOW AGILITY
1. En la pagina http://localhost:8080 (o similar) pincha en la sección **Conectar -> Flow Agility**.
2. Copia los 12 caracteres de la dirección mac.
3. Ve a la pagina de Flow Agility https://flowagility.com inicia sesión, accede a la prueba donde eres organizador y pincha en el icono para la gestión del crono en la parte superior
4. Pega la dirección mac que has copiado antes y dale a "Pair with timer"
5. La pagina cambiará y habra una dirección parecida a: flowagility.com/ws/timer/123456ABCDEF cópiala.
6. Vuelve a la pagina ZonEcron y en la casilla URL pega la dirección que has copiado y dale a conectar.
7. Si todo está correcto debería aparecer el mensaje "Conectado." en verde. Si no es así repasa todo el proceso desde el punto dos (ojo al copiar no incluyas algún espacio en blanco antes o después del texto). 
8. Una vez conectado, si vas a la pagina de Flow Agility también debería aparecer el crono como conectado. Si no es así prueba a refrescar la pagina.
9. Prueba a arrancar y parar el crono y ver que arranca y para en la pagina de Flow agility. También prueba a resetear el crono desde la pagina de Flow agility y comprueba que se haya reseteado. Ya tenemos la comunicación en ambas direcciones.

## MANEJAR EL CRONO DESDE LA APLICACION
1. El crono se puede manejar desde Flow Agility o desde la web **Mandos -> Crono** de esta aplicación.
2. Si estas conectado a Flow agility no necesitas este mando, y usar ambas opciones a la vez puede provocar errores al anotar los resultados.
3. El mando resulta bastante intuitivo. puedes subir y bajar faltas y rehuses, eliminar y des-eliminar, marcar tiempos de reconocimiento,...
4. Solo cabe destacar que para poder resetear el crono primero el competidor tiene que estar eliminado. Esto es así para evitar un reset involuntario ya que un reset no se puede deshacer. 

## VISUALIZAR CRONO EN PANTALLA
1. En la pagina http://localhost:8080 (o similar) pincha en la sección **Pantallas -> Monitor**. Esta pensado para mostrar el tiempo de cara al publico en un monitor medianamente grande que permita ver el tiempo desde cierta distancia.
2. Si la mochila esta conectada aparecerá el mismo tiempo que marque el crono así como las faltas y rehuses que le lleguen desde el Flow Agility, si éste está conectado.
3. Abajo del todo tienes dos selectores para cambiar el color del fondo y del texto por si le quieres dar un aspecto más festivo o corporativo, pero recomendamos usar colores que tengan un buen contraste entre ellos.
4. En la sección Pantallas -> Streaming podrás ver la misma información con fondo verde para poder hacer transparencias con programas dedicados a ello: 
 - Desde flow agility llegara automáticamente la información de la longitud de la pista, Si no estas conectado a Flow Agility tendrás que poner esta información a mano. Con esa información aparecerá un calculo en tiempo real de la velocidad en cada momento. 
 - Se pueden desplazar los textos de tiempo y velocidad horizontalmente.
 - Se puede aplicar un retardo en la visualización del crono para sincronizarlo con la imagen de video.

## MANEJAR Y VISUALIZAR EL TURNO DESDE LA APLICACION
1. Al igual que con el crono en **Mandos -> Turno** es posible manejar una indicación del numero de perro que esta en pista.
2. Esto está pensado para mostrar **Pantallas -> Turno** en un monitor a parte del crono, que los competidores puedan ver el numero desde lejos y organizar sus tiempos de preparación.
2. Al igual que con el crono esta información también llega desde Flow Agility (función en desarrollo) así que si estas conectado a Flow Agility no uses el mando del turno de esta aplicación.
3. Al igual que con la pantalla del crono, se pueden cambiar los colores de la pantalla del turno con los desplegables en la parte inferior

## STREAMING
1. La pagina **Pantallas -> FA Streaming** está pensada para ser capturada por programas de streaming. Es la misma pagina que tenemos disponible en  https://github.com/Danebae/FlowAgilityStreamingInfo pero preconfigurada para mostrar el tiempo del crono directamente.
2. Para mostrar la informacion de perro en pista y las clasificaciones, será necesario disponer de la URL de conexión proporcionada por la plataforma Flow Agility y configurarla en el menú general de la pantalla. La API utilizada está descrita en https://github.com/flowagility/streaming#flowagility-streaming-service-v100
3. Una vez en la pantalla, podemos hacer doble click en un cualquier punto vacio y podremos editar valores generales (como el color del fondo) y hablitar el modo edición.
4. En modo edicion, podremos pinchar y arrastrar los elementos para posicionarlos donde nos guste, y haciendo doble click en cada elemento podremos cambiar su tamaño, color, transparencia, textos...
5. Una vez terminado hacemos doble click de nuevo en una zona vacia y salimos del modo edicion para dejarlo funcionando.
6. Si ademas le damos a Guardar, los ajustes se mantendran aunque cerremos la pagina y la volvamos a abrir más tarde.
7. Igualmente si el programa de streaming ya esta mostrando esta pantalla, y queremos hacer modificaciones durante la transmision, podemos abrir otra ventana, hacer las modificaciones y al darle a salvar, se actualizará la pantalla que esta mostrando el streaming, sin que se haya visto como hemos hecho las modificaciones.
7. Muchos de los botones y valores tienen una ayuda contextual que aparece si detenemos el raton sobre el elemento un par de segundos.

## MULTIPLES CRONOS
1. Es posible ejecutar el programa varias veces si se dispone de varias mochilas con sus cronos para pistas simultáneas por ejemplo.
2. En ese caso cada ejecución creara un servidor en la misma dirección pero con diferente puerto, por ejemplo: http://localhost:8080 y http://localhost:8081 . Las direcciones mac para conectar con Flow Agility serán consecutivas
3. Las paginas de los primeros servidores se abrirán con colores diferentes para poder diferenciarlas cómodamente.

## INFORMACION
1. En la web **Información -> Sistema** 
 - Podrás ver las direcciones para acceder a la aplicación desde el ordenador donde se ejecuta o desde otro dispositivo en la misma red que el ordenador. Si por ejemplo tienes el ordenador conectado a una wifi, y tu móvil también, puedes acceder a la aplicación desde el móvil poniendo en el navegador web la dirección que aparece en esta pagina de información.
 - Podrás ver el estado de las baterías de la células ZonEcron.
 - Puedes ver información básica de la mochila (aburrriiiiidooooooo).
 - Puedes ver los últimos 10 tiempos que ha registrado el crono hoy (mientras haya estado conectado).
2. En la web **Información -> Tiempos** dispones de todos los tiempos que ha registrado el crono hoy. También tienes los de días pasados en archivos (uno por día) en la carpeta "logs" dentro de la carpeta de la aplicación.
3. En la web **Información -> Manual** puedes consultar este manual
4. En la web **Información -> Acerca de** puedes leer la licencia de uso, que básicamente te deja que uses la aplicación como quieras, pero sin ninguna garantía.

## VENTANA "NO CERRAR"
1. Al arrancar la aplicación se abre una ventana que no debes cerrar, que es básicamente la aplicación en si (las paginas web solo son un intermediario gráfico)
2. Es posible meter una serie de comandos en esa ventana para hacer pruebas o buscar fallos
3. teclea "ayuda" o "comandos" en esa ventana para mas información.

## NOTAS
1. Todos los datos de configuración se guardarán y la próxima vez que tengas que arrancar la aplicación se conectará automáticamente si tienes la mochila conectada y la dirección mac en la pagina de Flow Agility.
2. Es posible conectar solo la mochila para visualizar los tiempos en la pantalla de ordenador, o conectar solo el Flow Agility para hacer pruebas y familiarizarse con el entorno. Para ello hay una serie de comandos que se pueden teclear en esta misma ventana para simular el funcionamiento del crono. Para ver un listado de comandos completo teclea HELP + intro o AYUDA + intro.
