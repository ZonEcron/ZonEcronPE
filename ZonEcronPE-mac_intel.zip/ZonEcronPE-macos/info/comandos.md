# ZONECRON PUERTA DE ENLACE - COMANDOS PARA CONSOLA V 0.3.1

## INFO-DEBUG

| Ejemplo       | Descripción                                           | Notas                    |
|---------------|-------------------------------------------------------|--------------------------|
| HELP          | Muestra esta información                              |                          |
| LICENSE       | Muestra la licencia del copyright                     |                          |
| MANUAL        | Muestra instrucciones de conexión a Flow Agility      |                          |
| INFO          | Muestra info de conexiones, redes y puertos serie     |                          |
| DEBUG         | Muestra el estado de los mensajes de debug activos    |                          |
| DEBUG WSC     | Activa/desactiva los mensajes debug cliente websocket |                          |
| CLEAR         | Limpia la consola                                     |                          |
| EXIT          | Termina la ejecución de la aplicación                 |                          |

## PUERTOS SERIE
| Ejemplo       | Descripción                                           | Notas                    |
|---------------|-------------------------------------------------------|--------------------------|
| SERIAL        | Muestra un listado de los puertos serie disponibles   |                          |
| SERIAL COM3   | Cierra el puerto serie actual e intenta abrir COM3    |                          |

## CRONO
| Ejemplo       | Descripción                                           | Notas                    |
|---------------|-------------------------------------------------------|--------------------------|
| START         | Arranca el crono de 0                                 | sólo SIN mochila         |
| START 3500    | Arranca el crono marcando 3500ms. = 3,5s.             | sólo SIN mochila         |
| STOP          | Para el crono marcando el tiempo que haya contado     | sólo SIN mochila         |
| STOP 36748    | Para el crono marcando 36748ms. = 36,74s.             | sólo SIN mochila         |
| DATA 2:1:0    | Envía 2 faltas, 1 rehuse y no eliminado               |                          |
| RESET         | Pone tiempo, faltas, rehuses y eliminado a 0 y parado |                          |
| WALK          | Inicia reconocimiento de pista 7 minutos              |                          |
| WALK 360      | Inicia reconocimiento de pista 360s. = 6 minutos      |                          |
| DOWN          | Inicia cuenta 15s. para que el guia inicie la pista   | aún no con Flow Agility  |
| DOWN 20       | Inicia cuenta 20s. para que el guia inicie la pista   | aún no con Flow Agility  |
| DOWN 0        | Desactiva el modo suenta atras para salida            |                          |
| FAIL          | Alguna fotocélula está en alarma                      | desaparece en 5 segundos |
| OK            | Borra estado FAIL = Todas las celulas están ok        |                          |
