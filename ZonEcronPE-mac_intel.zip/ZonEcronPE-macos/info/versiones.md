# ZONECRON PUERTA DE ENLACE - REGISTRO DE VERSIONES Y CAMBIOS V 0.3.1

## 0.1.0 - 18/01/2023  
-   Primera versión funcional y comienzo del Betatesting.

## 0.2.0 - 29/01/2023
- Añadido este archivo con notas de la versión.
- Mejorado verificación de archivo de configuración.
- Añadido Manual en pagina web.
- Añadido compilar.js para automatizar la creacion de comprimidos para distribución
- Añadido mando web
- Añadido consulta de metros de pista a Flow Agility.
- Añadido web con info de celulas y mochila (falta horas celula)
- Añadido registro de tiempos
- Añadido funcion ultimos tiempos
- Añadido cambio de color del logotipo en funcion al puerto
- Añadido soporte para turno desde Flow Agilty + mando + visualizacion
- Añadido indicacion de altuira de salt en pantalla turno y mando turno
- Añadido direccion IP en pagina info y pantalla inicial consola.

## 0.2.1 - 02/02/2023
- Corregido "Altura Null" en pantalla suTurno
- Cambiado nombre de archivos cronoLog para que al ejecutar la aplicacion varias veces cada istancia guarde con nombre diferente
- Añadido comnado "EXIT" en consola
- Retoques en el manual
- Añadido manual en PDF en los comprimidos
- Retocado sistema de lectura/escritura de archivos de registro de tiempos

## 0.2.2 - 12/02/2023
- Verificado redirección de telegramas desde y hacia cada término
- Correcciones ortografía
- Añadidos PDFs de licencia y comandos

## 0.2.3 - 03/05/2023
- Mejorado opciones de personalización de la pantalla de streaming
- Añadido archivo versiones al paquete de distribución
- Eliminado responsive de las pantallas de crono y turno para poder cambiar tamaño manualmente

## 0.3.0 - 26/10/2023
- Renombrado pantalla Streaming a Stream Crono
- Mejorado arrastrar y soltar de la pantalla de Stream Crono
- Añadido pantalla "Stream Info" para recibir info desde Flow Agility y mostrar en Streaming

## 0.3.1 - 22/02/2024
- Arreglado algunos bugs de conexion y desconexión del puerto serie
- Sustituidas paginas de streaming por FAStreamingInfo: https://github.com/Danebae/FlowAgilityStreamingInfo
