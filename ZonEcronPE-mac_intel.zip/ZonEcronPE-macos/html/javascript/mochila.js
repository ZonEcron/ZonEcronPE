
var docSerSta = document.getElementById('serialStatus');
var docSerLis = document.getElementById('serialList');
var docBConec = document.getElementById('bConectar');
var docBRefre = document.getElementById('bRefrescar');
var docSerBau = document.getElementById('serialBaud');

var serStatus = 0;
var serConnected = null;
var retNoPing = 60000;
var noPingTimer = setTimeout(noPing, retNoPing);
var connection = new WebSocket('ws://' + location.host + '/');

connection.onopen = () => { connection.send("0A0"); };
connection.onclose = () => {
    docSerSta.style.color = "#F00";
    docSerSta.innerHTML = "Reiniciar aplicación.";
    docBConec.disabled = true;
    docBRefre.disabled = true;
}
connection.onmessage = function (mensaje) {

    if (mensaje.data == '__ping__') {
        clearTimeout(noPingTimer);
        noPingTimer = setTimeout(noPing, retNoPing);
        return;
    }
    console.log(mensaje.data);
    var datos = mensaje.data.split(";");
    if (datos[0] == "0A0") {
        docBConec.disabled = false;
        docBRefre.disabled = false;
        docSerLis.length = 0;

        // Opcion cuando no conectado
        const opcionCero = document.createElement("option");
        opcionCero.selected = true;
        opcionCero.disabled = true;
        opcionCero.textContent = "Seleccione Puerto";
        docSerLis.appendChild(opcionCero);

        // Resto de puertos
        const puertos = datos[2].split(',');
        puertos.forEach(puerto => {
            const opcionPuerto = document.createElement("option");
            opcionPuerto.value = puerto;
            opcionPuerto.textContent = puerto;
            docSerLis.appendChild(opcionPuerto);
        });

        docSerLis.value = datos[1];

        serStatus = parseInt(datos[3]);
        if (serStatus === 0) {
            serConnected = null;
            docSerSta.style.color = "#000";
            docBConec.innerHTML = 'Conectar';
        } else if (serStatus < 4) {
            serConnected = null;
            docSerSta.style.color = "#F00";
            docBConec.innerHTML = 'Conectar';
        } else if (serStatus < 7) {
            serConnected = datos[1];
            docSerSta.style.color = "#FA0";
            docBConec.innerHTML = 'Desconectar';
        } else if (serStatus === 7) {
            serConnected = datos[1];
            docSerSta.style.color = "#080";
            docBConec.innerHTML = 'Desconectar';
        }

        docSerSta.innerHTML = datos[4];
        docSerBau.value = datos[5];

    }
}
function connectSerial() {
    if (docSerLis.selectedIndex !== 0) {
        docBConec.disabled = true;
        const serSelected = serStatus < 4
            ? docSerLis.value
            : serConnected;
        const serBauds = docSerBau.value;
        connection.send(`1A0;${(serStatus < 4) * 1};${serSelected};${serBauds}`);
    }
}
function refreshSerial() {
    docBRefre.disabled = true;
    connection.send('1A0;2');
}
function noPing() { location.reload(); }