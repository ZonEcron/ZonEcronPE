document.getElementById("menu").innerHTML = `
<ul>
<li class="collapse" id="inforSub"><b><span>- Información</span></b></li>
<li class="inforSub" name="subOpt"><a href="index.html?info=manual"  >└-> Manual      </a></li>
<li class="inforSub" name="subOpt"><a href="sistema.html"            >└-> Sistema     </a></li>
<li class="inforSub" name="subOpt"><a href="tiempos.html"            >└-> Tiempos     </a></li>
<li class="inforSub" name="subOpt"><a href="index.html?info=licencia">└-> Licencia    </a></li>
<br>
<li class="collapse" id="conecSub"><b><span>- Conectar</span></b></li>
<li class="conecSub" name="subOpt"><a href="mochila.html"            >└-> Mochila     </a></li>
<li class="conecSub" name="subOpt"><a href="flowAgility.html"        >└-> Flow Agility</a></li>
<br>
<li class="collapse" id="mandoSub"><b><span>- Mandos</span></b></li>
<li class="mandoSub" name="subOpt"><a href="mandoCrono.html"         >└-> Crono       </a></li>
<li class="mandoSub" name="subOpt"><a href="mandoTurno.html"         >└-> Turno       </a></li>
<br>
<li class="collapse" id="pantaSub"><b><span>- Pantallas</span></b></li>
<li class="pantaSub" name="subOpt"><a href="monitorCrono.html"       >└-> Crono       </a></li>
<li class="pantaSub" name="subOpt"><a href="monitorTurno.html"       >└-> Turno       </a></li>
<li class="pantaSub" name="subOpt"><a href="FAstreamInfo.html"       >└-> FA Streaming</a></li>
</ul>
`;

/* nombre de archivo de la pagina actual */
const thisUrl = window.location.pathname;
const thisFilename = thisUrl.substring(thisUrl.lastIndexOf('/') + 1);

/* listas de elementos del menu */
const collap = document.getElementsByClassName("collapse");
const subOpt = document.getElementsByName("subOpt");

/* ocultar todos los submenus */
for (let j = 0; j < subOpt.length; j++) {
    subOpt[j].style.display = "none";
}

/* mostrar el submenu que corresponde a la pagina actual*/
for (let j = 0; j < subOpt.length; j++) {

    if (thisFilename === "index.html"        && subOpt[j].className === "inforSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "sistema.html"      && subOpt[j].className === "inforSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "tiempos.html"      && subOpt[j].className === "inforSub") { subOpt[j].style.display = "block"; }

    if (thisFilename === "mochila.html"      && subOpt[j].className === "conecSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "flowAgility.html"  && subOpt[j].className === "conecSub") { subOpt[j].style.display = "block"; }

    /* estos nunca empezaran abiertos porque en sus paginas no hay menu */
    /*
    if (thisFilename === "mandoCrono.html"   && subOpt[j].className === "mandoSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "mandoTurno.html"   && subOpt[j].className === "mandoSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "monitorCrono.html" && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "monitorTurno.html" && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "streamCrono.html"  && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
    if (thisFilename === "streamInfo.html"   && subOpt[j].className === "pantaSub") { subOpt[j].style.display = "block"; }
    */
}

/* añadir escuchadores para contraer y expandir seciones del menu */
for (let i = 0; i < collap.length; i++) {
    collap[i].addEventListener("click", function () {
        for (let j = 0; j < subOpt.length; j++) {
            if (subOpt[j].className === this.id) {
                if (subOpt[j].style.display === "block") {
                    subOpt[j].style.display = "none";
                } else {
                    subOpt[j].style.display = "block";
                }
            } else {
                // contraer menu cuando se clicka en otro diferente
                // subOpt[j].style.display = "none";
            }
        }
    });
}
