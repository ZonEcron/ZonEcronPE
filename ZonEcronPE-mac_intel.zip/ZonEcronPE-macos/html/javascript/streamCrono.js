/* ----- VARIABLES DE CRONO Y RESULTADOS ----- */
var inicio = new Date().getTime();
var tiem = 0;
var modo = "p";
var intervalo;

var vFal = 0;
var vReh = 0;
var vEli = 0;
var velo = "-.-";

/* ----- COMUNICACION WEBSOCKET Y HEARTBEAT ----- */
const retNoPing = 60000;
var noPingTimer = setTimeout(noPing, retNoPing);
var connection;

/* ----- VARIABLES RETARDO STREAMING Y SUAVIZADO ----- */
var delayTimer;

var retSuave = 5000;
var suaveTimer;
var suavizado = false;
var suavizar = true;

/* ----- ELEMENTOS CRONO ----- */
const tiempo = document.getElementById("tiempo");
const veloci = document.getElementById("velocidad");
const faltas = document.getElementById("faltas");
const rehuse = document.getElementById("rehuse");
const eliRec = document.getElementById("eliminado-reconocimiento");


/* ----- SELECTORES POR CLASE ----- */
const dragable = document.getElementsByClassName("dragable");
const animable = document.getElementsByClassName("animable");
const ventana = document.getElementsByClassName("ventana");
const ventanaTitulo = document.getElementsByClassName("ventanaTitulo");

/* ----- VENTANA PROPIEDADES ELEMENTOS CRONO ----- */
const modal = document.getElementById('modal');
const modalTitulo = document.getElementById('modalTitulo');
const font = document.getElementById("font");
const size = document.getElementById("size");
const colo = document.getElementById("colo");
const fond = document.getElementById("fond");
const anch = document.getElementById("anch");
const posX = document.getElementById("posX");
const posY = document.getElementById("posY");
const posZ = document.getElementById("posZ");
const tex1 = document.getElementById("tex1");
const tex2 = document.getElementById("tex2");
const tituloTextos = document.getElementById("tituloTextos");
const labelTex1 = document.getElementById("labelTex1");
const labelTex2 = document.getElementById("labelTex2");

/* ----- VENTANA PROPIEDADES GENERALES ----- */
const general = document.getElementById('general');
const generalTitulo = document.getElementById('generalTitulo');
const metros = document.getElementById("metros");
const maxVel = document.getElementById("maxVel");
const retDelay = document.getElementById("retDelay");
const selSuavizar = document.getElementById("selSuavizar");
const inpRetSuave = document.getElementById("inpRetSuave");
const fondo = document.getElementById("fondo");
const colorFondo = document.getElementById("colorFondo");
const botonEditar = document.getElementById("botonEditar");

/* ----- VENTANA EMERGENTE AYUDA -----*/
var infoTimeout;
const vInfo = document.getElementById("vInfo");


main();


/* ----- FUNCION INICIAL ----- */
function main() {

	/* ----- COMUNICACION WEBSOCKET ----- */
	connection = new WebSocket('ws://' + location.host + '/');
	connection.onopen = function () {
		connection.send("d0");
		connection.send("0C0");
	};
	connection.onmessage = function (mensaje) {
		console.log(mensaje.data);
		let datos = mensaje.data;
		if (datos === '__ping__') {
			clearTimeout(noPingTimer);
			noPingTimer = setTimeout(noPing, retNoPing);
		} else if (isNaN(datos.substring(0, 1)) && datos.length === 11) {
			delayTimer = setTimeout(function () {
				console.log(datos);
				miraModo(datos);
			}, retDelay.value * 1);
		} else {
			let dato = datos.split(';');
			if (dato[0] === '0S0') {
				console.log(datos);
				if (dato[1] * 1 > 0) {
					metros.value = dato[1] * 1;
				}
			}
			if (dato[0] === '0C0') {

				let ajustes = JSON.parse(mensaje.data.slice(4));

				console.log(ajustes);

				metros.value = ajustes.visual.metros || 200;
				maxVel.value = ajustes.visual.maxVel || 25;
				retDelay.value = ajustes.visual.retDelay || 0;

				selSuavizar.selectedIndex = ajustes.visual.suavizar || 0;
				inpRetSuave.value = ajustes.visual.retSuave || 5000;
				fondo.style.backgroundColor = ajustes.visual.colorFondo || "#000000";

				for (let item of dragable) {

					item.style.fontFamily = ajustes[item.id].font;
					item.style.fontSize = ajustes[item.id].size * 1 + 'px';
					item.style.color = ajustes[item.id].colo;
					item.style.backgroundColor = ajustes[item.id].fond;

					item.style.height = ajustes[item.id].alto * 1 + 'px';
					item.style.width = ajustes[item.id].anch * 1 + 'px';
					item.style.left = ajustes[item.id].posX * 1 + 'px';
					item.style.top = ajustes[item.id].posY * 1 + 'px';
					item.style.zIndex = ajustes[item.id].posZ * 1;

					item.font = ajustes[item.id].font;
					item.size = ajustes[item.id].size;
					item.colo = ajustes[item.id].colo;
					item.fond = ajustes[item.id].fond;					

					item.alto = ajustes[item.id].alto;
					item.anch = ajustes[item.id].anch;
					item.posX = ajustes[item.id].posX;
					item.posY = ajustes[item.id].posY;
					item.posZ = ajustes[item.id].posZ;

					item.tex1 = ajustes[item.id].tex1;
					item.tex2 = ajustes[item.id].tex2;

				}

				miraModo(modo + vFal + vReh + vEli + ('0000000' + tiem).slice(-7));
				recofaltuse();
				cambiaSuavizar();

			}
		}
	};

	/* ----- TEXTOS POR DEFECTO DE LOS ELEMENTOS DEL CRONO -----*/
	tiempo.tex1 = "";
	tiempo.tex2 = "";
	veloci.tex1 = "";
	veloci.tex2 = " m/s";
	faltas.tex1 = "F";
	faltas.tex2 = "";
	rehuse.tex1 = "R";
	rehuse.tex2 = "";
	eliRec.tex1 = "ELIMINADO";
	eliRec.tex2 = "RECONOCIM";

	/* ----- FLAG MODO EDICION -----*/
	general.editando = false;

	/* ----- CONFIGURAR ELEMENTOS SUAVIZABLES ----- */
	for (let item of animable) {

		item.addEventListener("animationstart", () => {
			//console.log('animation started');
		});

		item.addEventListener("animationiteration", () => {
			item.style["-webkit-animation-direction"] = "reverse";
			miraModo('p0000000000');
			suavizado = true;
			//console.log('animation iterated');
		});

		item.addEventListener("animationend", () => {
			item.style["-webkit-animation-direction"] = "normal";
			item.classList.remove("active");
			//console.log('animation end');
		});

	}

	/* ----- CONFIGURAR ELEMENTOS ARRASTRABLES ----- */
	for (let item of dragable) {
		makeDragable(item);
		item.addEventListener("dblclick", function () {

			if (general.editando) {

				modalTitulo.innerHTML = "<b>Propiedades " + item.id + "</b>";

				if (item.id === "eliminado-reconocimiento") {
					tituloTextos.innerHTML = "Textos para";
					labelTex1.innerHTML = "Eliminado";
					labelTex2.innerHTML = "Reconocimiento";
				} else {
					tituloTextos.innerHTML = "Textos antes y después";
					labelTex1.innerHTML = "Antes";
					labelTex2.innerHTML = "Después";
				}

				dragPropperties(item);
				modal.elemento = item;

				font.value = item.font;
				size.value = item.size;
				colo.value = item.colo;
				fond.value = item.fond;

				alto.value = item.alto;
				anch.value = item.anch;

				posX.value = item.posX;
				posY.value = item.posY;
				posZ.value = item.posZ;

				tex1.value = item.tex1;
				tex2.value = item.tex2;

				modal.style.display = "block";
			}
		});

	}

	/* ----- CONFIGURAR ELEMENTOS DE VENTANAS ----- */
	for (let item of ventana) {
		makeDragable(item);					//hacemos arrastrables las ventanas y  barra de titulo 
	}
	for (let item of ventanaTitulo) {
		makeDragable(item);
		item.isDragable = false;			// evitamos que la barra de la ventana sea arrastrable para que las funciones drag lo intenten con el padre contenedor
	}

	/* ----- CONTROLADORES DE EVENTOS -----*/
	window.onclick = function (event) {
		if (event.target != modal && !modal.contains(event.target)) {
			modalCancelar();
		}
		if (event.target != general && !general.contains(event.target)) {
			generalCancelar();
		}
	}
	window.ondblclick = function (event) {
		window.getSelection()?.removeAllRanges();
		if (event.target == fondo) {

			const compStyle = window.getComputedStyle(fondo);
			colorFondo.value = rgbaToHex(compStyle.getPropertyValue("background-color"))

			general.metros = metros.value;
			general.maxVel = maxVel.value;
			general.retDelay = retDelay.value;
			general.suavizar = selSuavizar.selectedIndex;
			general.retSuave = inpRetSuave.value;
			general.colorFondo = colorFondo.value;

			general.style.display = "block";

		}
	}
	document.addEventListener("mousemove", function (event) {
		var cursorX = event.pageX;
		var cursorY = event.pageY;
		vInfo.style.left = (cursorX + 50) + "px";
		vInfo.style.top = cursorY + "px";
	});

}

/* ----- FUNCION SUPERVISION LATIDO ----- */
function noPing() {
	location.reload();
}

/* ----- FUNCIONES CRONO ----- */
function miraModo(dato) {
	modo = dato.substring(0, 1);
	vFal = dato.substring(1, 2) * 1;
	vReh = dato.substring(2, 3) * 1;
	vEli = dato.substring(3, 4) * 1;
	tiem = dato.substring(4) * 1;
	clearInterval(intervalo);
	if (modo === "i") {
		inicio = new Date().getTime() - tiem;
		reloj(tiem, 0);
		ponVelocidad(tiem);
		intervalo = setInterval(function () { crono() }, 100);
	}
	if (modo === "p") {
		if (!suavizado || !suavizar) {
			inicio = new Date().getTime() - tiem;
			reloj(tiem, 1);
			ponVelocidad(tiem);
			if (dato != 'p0000000000' && suavizar) {
				clearTimeout(suaveTimer);
				suaveTimer = setTimeout(() => {
					for (let item of animable) {
						item.classList.add("active");
					}
				}, retSuave);
			}
		}
	} else {
		for (let item of animable) {
			item.classList.remove("active");
		}
		suavizado = false;
	}
	if (modo === "g" || modo === "o" || modo === "s" || modo === "q") {
		inicio = new Date().getTime() + tiem;
		reloj(tiem, 0);
		ponVelocidad(0);
		if (modo === "g" || modo === "s") {
			intervalo = setInterval(function () { atras() }, 100);
		}
	}
	if (!suavizado) {
		recofaltuse();
	}
}
function atras() {
	let actual = inicio - (new Date().getTime());
	if (actual < 0) {
		clearInterval(intervalo);
		reloj(0, 0);
		if (modo === 'g') {
			modo = 'p';
			vFal = 0;
			vReh = 0;
			vEli = 0;
			tiem = 0;
		}
		if (modo === 's') {
			modo = 'i';
			intervalo = setInterval(function () { crono() }, 100);
		}
		recofaltuse();
	} else {
		reloj(actual, 0);
	}
	ponVelocidad(0);
}
function crono() {
	let tiempoActual = new Date().getTime() - inicio;
	reloj(tiempoActual, 0);
	ponVelocidad(tiempoActual);
}
function reloj(muestraTiempo, muestraCentesimas) {
	var valor = "00.00";
	var enteros = Math.floor(muestraTiempo / 1000);
	var decimal = ("000" + muestraTiempo % 1000).slice(-3);
	var minutos = Math.floor(enteros / 60);
	var segundos = enteros % 60;
	if (minutos < 10) minutos = "0" + minutos;
	if (segundos < 10) segundos = "0" + segundos;
	if ((modo === 'o' || modo === 'g') && muestraTiempo > 0) {
		valor = minutos + ":" + segundos;
	} else if (muestraTiempo > 0) {
		if (muestraCentesimas) {
			decimal = decimal.substring(0, 2);
		} else {
			decimal = decimal.substring(0, 1) + "0";
		}
		valor = enteros + "." + decimal
	}
	tiempo.innerHTML = `${tiempo.tex1}${valor}${tiempo.tex2}`;
	//tiempo.innerHTML = valor;
}
function ponVelocidad(miTiempo) {
	/*
	veloci.style.display = (modo === 'g' || modo === 'o')
		? "none"
		: "block";
	*/

	veloci.style.visibility = (modo === 'g' || modo === 'o')
		? "hidden"
		: "visible";

	velo = "-.-";
	if (miTiempo > 5000 && !vEli) {
		velo = (metros.value / (miTiempo / 1000));
		if (velo > maxVel.value) {
			velo = '-.-';
		} else {
			velo = velo.toFixed(1);
		}
	}
	document.getElementById("velocidad").innerHTML = `${veloci.tex1}${velo}${veloci.tex2}`;
}
function recofaltuse() {

	if (modo === 'g' || modo === 'o' || vEli > 0) {
		if (!general.editando) {
			/*
			faltas.style.display = "none";
			rehuse.style.display = "none";
			eliRec.style.display = "block";
			*/
			faltas.style.visibility = "hidden";
			rehuse.style.visibility = "hidden";
			eliRec.style.visibility = "visible";
		}
		eliRec.innerHTML = (modo === 'g' || modo === 'o')
			? eliRec.tex2
			: eliRec.tex1;
	} else {
		if (!general.editando) {
			/*
			faltas.style.display = "block";
			rehuse.style.display = "block";
			eliRec.style.display = "none";
			*/
			faltas.style.visibility = "visible";
			rehuse.style.visibility = "visible";
			eliRec.style.visibility = "hidden";
		}
		faltas.innerHTML = `${faltas.tex1}${vFal}${faltas.tex2}`;
		rehuse.innerHTML = `${rehuse.tex1}${vReh}${rehuse.tex2}`;
	}
}

/* ----- FUNCIONES ELEMENTOS ARRASTRABLES ----- */
function makeDragable(element) {

	element.addEventListener("mousedown", dragStart);
	element.addEventListener("mouseup", dragEnd);
	//element.addEventListener("mouseout", dragEnd);
	element.addEventListener("mousemove", drag);

	element.isDragable = true;
	element.isDragging = false;

	element.mouseX = 0;
	element.mouseY = 0;

	element.dx = 0;
	element.dy = 0;

	dragPropperties(element);

}
function dragStart(e) {

	let target = e.target.isDragable
		? e.target
		: e.target.parentNode;

	if (target.isDragable && general.editando) {
		target.mouseX = e.clientX;
		target.mouseY = e.clientY;
		target.isDragging = true;
		target.style.border = "1px solid red";
		target.style.zIndex = 1000;
	}
}
function drag(e) {

	let target = e.target.isDragable
		? e.target
		: e.target.parentNode;

	if (target.isDragging) {
		target.dx = e.clientX - target.mouseX;
		target.dy = e.clientY - target.mouseY;
		target.style.left = (target.posX + target.dx) + 'px';
		target.style.top = (target.posY + target.dy) + 'px';
	}
}
function dragEnd(e) {

	let target = e.target.isDragable
		? e.target
		: e.target.parentNode;

	if (target.isDragging) {
		target.isDragging = false;
		target.style.border = "none";
		target.posX += target.dx;
		target.posY += target.dy;
		target.style.zIndex = target.posZ;
	}
}
function dragPropperties(e) {

	const compStyle = window.getComputedStyle(e);

	e.font = compStyle.getPropertyValue("font-family");
	e.size = parseInt(compStyle.getPropertyValue("font-size"), 10);
	e.colo = rgbaToHex(compStyle.getPropertyValue("color"));
	e.fond = rgbaToHex(compStyle.getPropertyValue("background-color"));

	e.alto = parseInt(compStyle.getPropertyValue("height"), 10);
	e.anch = parseInt(compStyle.getPropertyValue("width"), 10);

	e.posX = parseInt(compStyle.getPropertyValue("left"), 10);
	e.posY = parseInt(compStyle.getPropertyValue("top"), 10);
	e.posZ = parseInt(compStyle.getPropertyValue("z-index"), 10);

}

/* ----- FUNCIONES FORMATO ----- */
function rgbaToHex(rgba) {
	// convertir color rgba a formato hexadecimal
	const hex = rgba.match(/^(rgba|rgb)\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)$/);
	const r = parseInt(hex[2], 10).toString(16).padStart(2, '0').toUpperCase();
	const g = parseInt(hex[3], 10).toString(16).padStart(2, '0').toUpperCase();
	const b = parseInt(hex[4], 10).toString(16).padStart(2, '0').toUpperCase();
	const a = (hex[5]
		? Math.round(parseFloat(hex[5]) * 255).toString(16).padStart(2, '0')
		: "FF").toUpperCase();
	return `#${r}${g}${b}${a}`;
}

/* ----- FUNCIONES VENTANA DE PROPIEDADES ELEMENTOS ----- */
function modalAplicar() {

	modal.elemento.style.fontFamily = font.value;
	modal.elemento.style.fontSize = size.value * 1 + 'px';
	modal.elemento.style.color = colo.value;
	modal.elemento.style.backgroundColor = fond.value;

	modal.elemento.style.height = alto.value * 1 + 'px';
	modal.elemento.style.width = anch.value * 1 + 'px';

	modal.elemento.style.left = posX.value * 1 + 'px';
	modal.elemento.style.top = posY.value * 1 + 'px';

	let zMinMax = posZ.value * 1;
	if (zMinMax > 9) zMinMax = 9;
	if (zMinMax < 1) zMinMax = 1;
	modal.elemento.style.zIndex = zMinMax;

	modal.elemento.tex1 = tex1.value;
	modal.elemento.tex2 = tex2.value;

	miraModo(modo + vFal + vReh + vEli + ('0000000' + tiem).slice(-7));
	recofaltuse();

}
function modalAceptar() {
	modalAplicar()
	modal.style.display = "none";
}
function modalCancelar() {

	let modalEstado = getComputedStyle(modal);

	if (modalEstado.getPropertyValue("display") != "none") {

		modal.style.display = "none";

		modal.elemento.style.fontFamily = modal.elemento.font;
		modal.elemento.style.fontSize = modal.elemento.size * 1 + 'px';
		modal.elemento.style.color = modal.elemento.colo;
		modal.elemento.style.backgroundColor = modal.elemento.fond;

		modal.elemento.style.height = modal.elemento.alto * 1 + 'px';
		modal.elemento.style.width = modal.elemento.anch * 1 + 'px';

		modal.elemento.style.left = modal.elemento.posX * 1 + 'px';
		modal.elemento.style.top = modal.elemento.posY * 1 + 'px';
		modal.elemento.style.zIndex = modal.elemento.posZ * 1;

		modal.elemento.tex1 = modal.elemento.tex1;
		modal.elemento.tex2 = modal.elemento.tex2;

		miraModo(modo + vFal + vReh + vEli + ('0000000' + tiem).slice(-7));
		recofaltuse();

	}

}

/* ----- FUNCIONES VENTANA DE PROPIEDADES GENERAL ----- */
function generalAplicar() {

	fondo.style.backgroundColor = colorFondo.value;
	cambiaSuavizar();
	miraModo(modo + vFal + vReh + vEli + ('0000000' + tiem).slice(-7));
	recofaltuse();

}
function generalAceptar() {

	generalAplicar();
	general.style.display = "none";

}
function generalCancelar() {

	let generalEstado = getComputedStyle(general);

	if (generalEstado.getPropertyValue("display") != "none") {

		general.style.display = "none";

		metros.value = general.metros;
		maxVel.value = general.maxVel;
		retDelay.value = general.retDelay;
		selSuavizar.selectedIndex = general.suavizar;
		inpRetSuave.value = general.retSuave;
		fondo.style.backgroundColor = general.colorFondo;

		miraModo(modo + vFal + vReh + vEli + ('0000000' + tiem).slice(-7));
		recofaltuse();
	}

}
function generalReset() {
	connection.send("1C1");
	location.reload();
}
function generalEditar() {

	general.editando = !general.editando;

	if (general.editando) {

		botonEditar.innerHTML = "No Editar";

		/*
		veloci.style.display = "block";
		faltas.style.display = "block";
		rehuse.style.display = "block";
		eliRec.style.display = "block";
		*/
		veloci.style.visibility = "visible";
		faltas.style.visibility = "visible";
		rehuse.style.visibility = "visible";
		eliRec.style.visibility = "visible";

	} else {
		botonEditar.innerHTML = "Editar";
	}

	generalAplicar();

}
function generalGuardar() {
	generalAplicar();
	let ajustes = {
		visual: {
			"metros": metros.value,
			"maxVel": maxVel.value,
			"retDelay": retDelay.value * 1,
			"suavizar": selSuavizar.selectedIndex,
			"retSuave": inpRetSuave.value * 1,
			"colorFondo": colorFondo.value
		}
	}

	for (let item of dragable) {

		dragPropperties(item);

		ajustes[item.id] = {};

		ajustes[item.id].font = item.font;
		ajustes[item.id].size = item.size;
		ajustes[item.id].colo = item.colo;
		ajustes[item.id].fond = item.fond;
		ajustes[item.id].alto = item.alto;
		ajustes[item.id].anch = item.anch;
		ajustes[item.id].posX = item.posX;
		ajustes[item.id].posY = item.posY;
		ajustes[item.id].posZ = item.posZ;
		ajustes[item.id].tex1 = item.tex1;
		ajustes[item.id].tex2 = item.tex2;

	}

	console.log();

	connection.send("1C0;" + JSON.stringify(ajustes));

}
function cambiaSuavizar() {
	suavizar = selSuavizar.selectedIndex;
	retSuave = inpRetSuave.value * 1 || 5000;
	if (!suavizar) {
		clearTimeout(suaveTimer);
	}
}

/* ----- FUNCIONES VENTANA EMERGENTE AYUDA -----*/
function mInfo(tipo) {
	infoTimeout = setTimeout(function () {
		vInfo.style.display = "block";
		if (tipo === "visual") {
			vInfo.innerHTML = "Aplica temporalmente las modificaciones";
		}
		if (tipo === "aceptar") {
			vInfo.innerHTML = "Aplica las modificaciones y cierra esta ventana";
		}
		if (tipo === "cancelar") {
			vInfo.innerHTML = "Descarta las modificaciones y cierra esta ventana";
		}
		if (tipo === "editar") {
			vInfo.innerHTML = "Muestra los elementos ocultos para poder editarlos";
		}
		if (tipo === "guardar") {
			vInfo.innerHTML = "Aplica las modificaciones y guarda <b>todos los ajustes</b> en el servidor";
		}
		if (tipo === "reset") {
			vInfo.innerHTML = "Vuelve a los <b>ajustes 'de fabrica'</b> y elimina los ajustes guardados en el servidor";
		}
		if (tipo === "suavizar") {
			vInfo.innerHTML = "Al detenerse el crono, pasado el tiempo indicado en el retardo, tiempo, faltas y rehuses se pondran a 0 con un fundido suave. No afecta a la pantalla física del crono.";
		}
	}, 1500);
}
function oInfo() {
	clearTimeout(infoTimeout);
	vInfo.style.display = "none";
}
