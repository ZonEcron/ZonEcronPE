
var connection = new WebSocket('ws://' + location.host + '/');
const info = new URLSearchParams(window.location.search).get('info') || 'manual';

if (info === 'licencia') {
    connection.onopen = function () { connection.send("0B1"); };
    connection.onmessage = function (mensaje) {
        var datos = mensaje.data.split(";");
        if (datos[0] == "0B1") {
            document.getElementById("texto").innerHTML = datos[1];
            connection.close();
        }
    }
} else {
    connection.onopen = function () { connection.send("0B0"); };
    connection.onmessage = function (mensaje) {
        var datos = mensaje.data.split(";");
        if (datos[0] == "0B0") {
            document.getElementById("texto").innerHTML = datos[1];
            connection.close();
        }
    }
}