var tabla;
var conexion = 0;
var lineas = [];
var connection = new WebSocket('ws://' + location.host + '/');
connection.onopen = () => { connection.send("060"); };
connection.onmessage = function (mensaje) {
    var datos = mensaje.data.split(";");
    if (datos[0] == "060") {
        tabla = "<tr><th>nº</th><th>Hora</th><th>Tiempo</th><th>Fal</th><th>Reh</th><th>Eli</th></tr>";
        lineas = datos.slice(1);
        for (let i = 0; i < lineas.length; i++) {
            const campos = lineas[i].split('\t');
            const num = i + 1;
            tabla += "<tr>";
            tabla += "<td>" + num + "</td>";
            tabla += "<td>" + campos[0] + "</td>";
            tabla += "<td>" + campos[1] + "</td>";
            tabla += "<td>" + campos[2] + "</td>";
            tabla += "<td>" + campos[3] + "</td>";
            tabla += "<td>" + ((campos[4] === '1') ? 'Eliminado' : '') + "</td>";
            tabla += "</tr>";
        }
        document.getElementById("tiempos").innerHTML = tabla;
        connection.close();
    }
}